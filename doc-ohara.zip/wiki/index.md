---
title: "Doc Ohara Open Knowledge Graph Garden 🌌"
---

# 📡 Welcome to Doc Ohara Open Knowledge Garden

This Digital Garden is compiled directly from **Doc Ohara's** Multi-Model Space-Time Graph Simulator. It provides the "Layer Cake" structural and thematic mappings of all ingested material.

---

## 📚 Document Catalogue
Click on a document index card below to browse its hierarchical space-time ontology.

### 🗃️ [[documents/doc_quantum_physics|Introduction to Quantum Superposition & Qubit Mechanics]]
- **Document ID**: `doc_quantum_physics`
- **Total Vertices**: 6 nodes
- **Smart Hash**: `8a3cfd7b420e98c7...`
- **Extracted Date**: 2026-06-01T10:00:00.000Z

### 🗃️ [[documents/doc_cyber_compliance|Enterprise AI Security & Governance Framework]]
- **Document ID**: `doc_cyber_compliance`
- **Total Vertices**: 5 nodes
- **Smart Hash**: `2e9a8f4c28fe9b50...`
- **Extracted Date**: 2026-06-10T14:30:00.000Z


---

## 🧪 Global Louvain Thematic Hubs
Doc Ohara's Refinery continuously groups overlapping nodes into thematic virtual clubs. Below are the current active clusters:

### 🌀 Hub: `cluster_1` (Modularity Group)
*Consists of 7 related conceptual anchors:*

- In [[documents/doc_quantum_physics|Introduction to Quantum Superposition & Qubit Mechanics]]: `"Chapter 1: The Core Principles"` - *This chapter establishes the core mathematical formulation of quantum mechanics,...*
- In [[documents/doc_quantum_physics|Introduction to Quantum Superposition & Qubit Mechanics]]: `"Section 1.1: Superposition States"` - *Quantum superposition states are coherent linear combinations of basis states, u...*
- In [[documents/doc_quantum_physics|Introduction to Quantum Superposition & Qubit Mechanics]]: `"Paragraph"` - *To measure superposition, we choose a measurement basis (e.g. computational basi...*
- In [[documents/doc_quantum_physics|Introduction to Quantum Superposition & Qubit Mechanics]]: `"Paragraph"` - *This behavior has been experimentally verified in Dr. Jenkins' lab, showing cohe...*
- In [[documents/doc_quantum_physics|Introduction to Quantum Superposition & Qubit Mechanics]]: `"Section 1.2: Qubit Engineering"` - *A physical qubit is a two-level system utilized for quantum computing. Examples ...*
- In [[documents/doc_quantum_physics|Introduction to Quantum Superposition & Qubit Mechanics]]: `"Paragraph"` - *Control gates, such as the Hadamard and CNOT gates, allow arbitrary manipulation...*
- In [[documents/doc_cyber_compliance|Enterprise AI Security & Governance Framework]]: `"Paragraph"` - *When quantum decryption algorithms mature, typical RSA or symmetric systems are ...*

### 🌀 Hub: `cluster_7` (Modularity Group)
*Consists of 4 related conceptual anchors:*

- In [[documents/doc_cyber_compliance|Enterprise AI Security & Governance Framework]]: `"Chapter 1: AI Governance Guidelines"` - *This document delineates the security baseline of deployable Large Language Mode...*
- In [[documents/doc_cyber_compliance|Enterprise AI Security & Governance Framework]]: `"Section 1.1: Data Encryption and Sovereignty"` - *All operational weights and conversational transcripts must belong strictly to i...*
- In [[documents/doc_cyber_compliance|Enterprise AI Security & Governance Framework]]: `"Paragraph"` - *Standard AES-256 GCM encryption-at-rest is mandated. Dynamic key rotation must c...*
- In [[documents/doc_cyber_compliance|Enterprise AI Security & Governance Framework]]: `"Section 1.2: Threat Vector Analysis on AI Nodes"` - *AI computing infrastructure is susceptible to unique attack structures, includin...*


---
*Doc Ohara Engine: Interactive Knowledge Mapper — UTC June 2026*
