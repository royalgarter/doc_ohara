/**
 * Doc Ohara: Full-Stack Express Server with Gemini 3.5 RAG Sandbox
 */

import express from "express";
import * as path from "path";
import * as fs from "fs";
import { GoogleGenAI } from "@google/genai";
import { getDB } from "./src/db/simulator.js";
import { SpaceTimeTransformer } from "./src/pipeline/transformer.js";
import { SpaceTimeRetriever } from "./src/pipeline/retriever.js";
import { WikiExporter } from "./src/pipeline/wikiExporter.js";

const app = express();
const PORT = 3000;

app.use(express.json());
// Serve visual HTML client
app.use(express.static(path.resolve("./public")));

const db = getDB();
const transformer = new SpaceTimeTransformer();
const retriever = new SpaceTimeRetriever();

/**
 * Modern Google@genai Client Utility
 */
const getGeminiClient = (): GoogleGenAI | null => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// --- API Endpoints ---

/**
 * Fetch catalogued documents
 */
app.get("/api/documents", (req, res) => {
  try {
    const docs = db.getDocuments();
    res.json(docs);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Fetch all nodes within the graph
 */
app.get("/api/nodes", (req, res) => {
  try {
    const nodes = db.getNodes();
    res.json(nodes);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Fetch all edges
 */
app.get("/api/edges", (req, res) => {
  try {
    const edges = db.getEdges();
    res.json(edges);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Cascading document cleanup deletion
 */
app.delete("/api/documents/:id", (req, res) => {
  try {
    const { id } = req.params;
    db.deleteDocument(id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Start Ingestion transformation pipeline (Stage 1-7)
 */
app.post("/api/ingest", async (req, res) => {
  try {
    const { title, content, parserType } = req.body;
    if (!content) {
      res.status(400).json({ success: false, error: "Content is required." });
      return;
    }

    const result = await transformer.transform(title || "Doc_Untitled", content, {
      parserType: parserType || "GeminiFlashLite",
      forceReingest: true,
    });

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, log: [String(err)] });
  }
});

/**
 * Run two-step search (Phase 0, 1, 2)
 */
app.post("/api/query", async (req, res) => {
  try {
    const { query } = req.body;
    if (!query) {
      res.status(400).json({ error: "Query is required." });
      return;
    }

    // Phase 0: preprocess
    const processed = await retriever.preprocessQuery(query);

    // Phase 1: Shallow match
    const shallowMatches = await retriever.getShallowContext(processed, 5);

    if (shallowMatches.length === 0) {
      res.json({
        keywords: processed.keywords,
        tags: processed.tags,
        shallowMatches: [],
        deepResult: null,
        promptContextBlock: "",
      });
      return;
    }

    // Phase 2: Deep Context Walk from top match
    const topAnchor = shallowMatches[0].node;
    const deepResult = retriever.getDeepContext(topAnchor.id);
    let promptContextBlock = "";

    if (deepResult) {
      promptContextBlock = retriever.generateFullContextBlock(deepResult);
    }

    res.json({
      keywords: processed.keywords,
      tags: processed.tags,
      shallowMatches,
      deepResult,
      promptContextBlock,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Run standalone Phase 2 deep tree walk from visual node click
 */
app.post("/api/query_deep", async (req, res) => {
  try {
    const { nodeId } = req.body;
    const deepResult = retriever.getDeepContext(nodeId);
    let promptContextBlock = "";

    if (deepResult) {
      promptContextBlock = retriever.generateFullContextBlock(deepResult);
    }

    res.json({
      deepResult,
      promptContextBlock,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Human Audit corrections commit
 */
app.post("/api/audit/node", (req, res) => {
  try {
    const { nodeId, updatedContent, approved } = req.body;
    const success = db.auditNode(nodeId, updatedContent, approved);
    res.json({ success });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Export Quartz Wiki Digital Garden
 */
app.post("/api/export-wiki", (req, res) => {
  try {
    const exporter = new WikiExporter();
    const result = exporter.export();
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * List files in compiled wiki
 */
app.get("/api/wiki/files", (req, res) => {
  try {
    const wikiPath = path.resolve("./wiki");
    if (!fs.existsSync(wikiPath)) {
      res.json({ files: [] });
      return;
    }

    const files: string[] = ["index.md"];
    const docsDir = path.join(wikiPath, "documents");

    if (fs.existsSync(docsDir)) {
      const docFiles = fs.readdirSync(docsDir).filter((f) => f.endsWith(".md"));
      docFiles.forEach((f) => files.push(`documents/${f}`));
    }

    res.json({ files });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Read specific wiki file content
 */
app.get("/api/wiki/files/content", (req, res) => {
  try {
    const filename = String(req.query.filename || "index.md");
    // Secure filepath traversal check
    if (filename.includes("..")) {
      res.status(403).send("Traversal forbidden.");
      return;
    }

    const filePath = path.join(path.resolve("./wiki"), filename);
    if (fs.existsSync(filePath)) {
      res.header("Content-Type", "text/markdown");
      res.send(fs.readFileSync(filePath, "utf-8"));
    } else {
      res.status(444).send("Wiki file not compiled yet.");
    }
  } catch (err: any) {
    res.status(500).send(err.message);
  }
});

/**
 * Live Server-Side Gemini Chat Sandbox Playground (RAG)
 */
app.post("/api/gemini/play", async (req, res) => {
  try {
    const { question, context } = req.body;
    if (!question) {
      res.status(400).json({ error: "Question is required." });
      return;
    }

    const gemini = getGeminiClient();

    if (!gemini) {
      // High-quality Offline Simulated RAG Respondent fallback if key is missing!
      console.log("[SIMULATION MODE] Replying using mock RAG parser.");
      const keywords = question.toLowerCase().replace(/[^a-z0-9\s]/g, "").split(/\s+/);
      const nodes = db.getNodes();
      // Match keywords programmatically against nodes
      let responseText = `**[RAG Simulation Mode - Offline]** API key not set in Secrets panel. Here is a synthesized answer from local knowledge base:\n\n`;
      
      const relevance = nodes.map(n => {
        let sc = 0;
        keywords.forEach(kw => {
          if (n.content.toLowerCase().includes(kw)) sc += 1;
        });
        return { n, sc };
      }).sort((a,b)=>b.sc-a.sc).filter(item => item.sc > 0);

      if (relevance.length > 0) {
        responseText += `Based on active local section **${relevance[0].n.id}**: \n\n> "${relevance[0].n.content}"\n\n`;
        if (question.toLowerCase().includes("coherence") || question.toLowerCase().includes("superposition")) {
          responseText += `To measurement superconducting loops, choose computational bases. Dr. Jenkins' laboratory recently proved coherence benchmarking reaching 220 microseconds on Post-Quantum substrates. Integrating with local lattices optimizes enterprise parameters.`;
        } else {
          responseText += `Sovereignty isolation mandates isolated clouds to conform with regional policies (HIPAA & GDPR). Enterprise baseline security protects operations via out-of-band AES rotating keys.`;
        }
      } else {
        responseText += `The local simulator contains knowledge files about Quantum Coherence Loops and Enterprise Model Governance Baseline. Please try asking about "superposition" or "isolation keys".`;
      }

      res.json({ answer: responseText });
      return;
    }

    // Call modern gemini-3.5-flash for basic text reasoning task
    const systemPrompt = `You are the Doc Ohara Knowledge Assistant. Synthesize an elegant, professional response to the user's question USING ONLY the provided verified Space-Time graph context block. If the context is empty, say "No relevant context found in Space-Time graph". Keep it clear, concise, and structured.`;
    
    const response = await gemini.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Context Grid:\n${context || "No context loaded."}\n\nQuestion: ${question}`,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    res.json({
      answer: response.text || "Gemini returned empty text response.",
    });

  } catch (err: any) {
    res.status(500).json({ error: err.message, answer: `❌ Gemini Process Error: ${err.message}` });
  }
});

// Run server
app.listen(PORT, "0.0.0.0", () => {
  console.log(`=============================================================`);
  console.log(`🌌 DOC OHARA APPLICATION SERVER ONLINE ON PORT ${PORT}`);
  console.log(`👉 Preview URL: http://localhost:${PORT}`);
  console.log(`=============================================================`);
});
