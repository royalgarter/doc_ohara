/**
 * Doc Ohara: Graph Database Simulator (ArangoDB behavior with JSON disk persistence)
 */

import * as fs from "fs";
import * as path from "path";
import { DBState, OKFDocument, OKFNode, OKFEdge, NodeType, EdgeType } from "../types.js";

const DATA_DIR = path.resolve("./data");
const DB_PATH = path.join(DATA_DIR, "db.json");

export class GraphDBSimulator {
  private state: DBState = {
    documents: {},
    nodes: {},
    edges: {},
  };

  constructor() {
    this.initDb();
  }

  /**
   * Initializes database on disk. Seed with demo documents if empty.
   */
  private initDb() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_PATH)) {
        const raw = fs.readFileSync(DB_PATH, "utf-8");
        this.state = JSON.parse(raw);
      } else {
        this.seedDemoData();
        this.saveToDisk();
      }
    } catch (err) {
      console.error("Error initializing Database Simulator:", err);
      // Fallback to empty in-memory state
      this.state = { documents: {}, nodes: {}, edges: {} };
    }
  }

  /**
   * Saves current state to disk.
   */
  private saveToDisk() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_PATH, JSON.stringify(this.state, null, 2), "utf-8");
    } catch (err) {
      console.error("Failed to write graph state to disk:", err);
    }
  }

  /**
   * Seed high-fidelity sample data modeling after an academic quantum physics paper
   * and a corporate cybersecurity compliance manual.
   */
  private seedDemoData() {
    const doc1: OKFDocument = {
      doc_id: "doc_quantum_physics",
      title: "Introduction to Quantum Superposition & Qubit Mechanics",
      content_hash: "8a3cfd7b420e98c772db15217483ef339cf9e5df5a3c98dc215ab71f28b7beef",
      created_at: new Date("2026-06-01T10:00:00Z").toISOString(),
      metadata: {
        author: "Dr. Jenkins, Quantum Labs",
        version: "1.2",
        license: "CC-BY-4.0",
      },
    };

    const doc2: OKFDocument = {
      doc_id: "doc_cyber_compliance",
      title: "Enterprise AI Security & Governance Framework",
      content_hash: "2e9a8f4c28fe9b502c1782ee91b9ef4c1a2d3f66a9e88dc6a55ef769cb89eeee",
      created_at: new Date("2026-06-10T14:30:00Z").toISOString(),
      metadata: {
        author: "Compliance Board",
        version: "3.0",
        license: "Proprietary",
      },
    };

    this.state.documents[doc1.doc_id] = doc1;
    this.state.documents[doc2.doc_id] = doc2;

    // --- Nodes for Quantum Superposition Doc ---
    const qNodes: OKFNode[] = [
      {
        id: "q_ch1",
        doc_id: "doc_quantum_physics",
        type: "Chapter",
        title: "Chapter 1: The Core Principles",
        content: "This chapter establishes the core mathematical formulation of quantum mechanics, detailing state spaces and operators.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-01T00:00:00Z" },
        tags: ["Quantum", "Physics", "Linear-Algebra"],
        confidence: 0.98,
        requires_review: false,
      },
      {
        id: "q_sec1_1",
        doc_id: "doc_quantum_physics",
        type: "Section",
        title: "Section 1.1: Superposition States",
        content: "Quantum superposition states are coherent linear combinations of basis states, usually denoted as |psi> = a|0> + b|1>.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-01T00:00:00Z" },
        tags: ["Superposition", "Math", "Linear-Algebra"],
        confidence: 0.95,
        requires_review: false,
      },
      {
        id: "q_p1",
        doc_id: "doc_quantum_physics",
        type: "Paragraph",
        content: "To measure superposition, we choose a measurement basis (e.g. computational basis). The probability of finding the system in |0> is given as |a|^2 and in |1> is |b|^2.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-01T00:00:00Z" },
        tags: ["Measurement", "Probability"],
        confidence: 0.88,
        requires_review: false,
      },
      {
        id: "q_p2",
        doc_id: "doc_quantum_physics",
        type: "Paragraph",
        content: "This behavior has been experimentally verified in Dr. Jenkins' lab, showing coherence times exceeding 100 microseconds.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-01T00:00:00Z" },
        tags: ["Experiment", "Lab", "Coherence"],
        confidence: 0.92,
        requires_review: false,
      },
      {
        id: "q_sec1_2",
        doc_id: "doc_quantum_physics",
        type: "Section",
        title: "Section 1.2: Qubit Engineering",
        content: "A physical qubit is a two-level system utilized for quantum computing. Examples include superconducting Josephson junctions and trapped ions.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-01T00:00:00Z" },
        tags: ["Qubits", "Hardware", "Josephson-Junctions"],
        confidence: 0.65, // Let's flag this node for review to test audit feature!
        requires_review: true,
      },
      {
        id: "q_p3",
        doc_id: "doc_quantum_physics",
        type: "Paragraph",
        content: "Control gates, such as the Hadamard and CNOT gates, allow arbitrary manipulation of the Bloch Sphere coordinates of these qubits.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-01T00:00:00Z" },
        tags: ["Gates", "Bloch-Sphere", "Hadamard"],
        confidence: 0.90,
        requires_review: false,
      },
    ];

    // --- Nodes for Cyber Compliance Doc ---
    const cNodes: OKFNode[] = [
      {
        id: "c_ch1",
        doc_id: "doc_cyber_compliance",
        type: "Chapter",
        title: "Chapter 1: AI Governance Guidelines",
        content: "This document delineates the security baseline of deployable Large Language Models inside enterprise clouds.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-10T00:00:00Z" },
        tags: ["AI", "Governance", "Security"],
        confidence: 0.97,
        requires_review: false,
      },
      {
        id: "c_sec1_1",
        doc_id: "doc_cyber_compliance",
        type: "Section",
        title: "Section 1.1: Data Encryption and Sovereignty",
        content: "All operational weights and conversational transcripts must belong strictly to isolated sovereign cloud tenancies to comply with HIPAA and GDPR.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-10T00:00:00Z" },
        tags: ["Compliance", "Encryption", "Sovereign-Cloud"],
        confidence: 0.70, // Flagged for human review
        requires_review: true,
      },
      {
        id: "c_p1",
        doc_id: "doc_cyber_compliance",
        type: "Paragraph",
        content: "Standard AES-256 GCM encryption-at-rest is mandated. Dynamic key rotation must carry out of band every 90 days or upon tenant change.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-10T00:00:00Z" },
        tags: ["Symmetric-Crypt", "Keys", "Rotation"],
        confidence: 0.94,
        requires_review: false,
      },
      {
        id: "c_sec1_2",
        doc_id: "doc_cyber_compliance",
        type: "Section",
        title: "Section 1.2: Threat Vector Analysis on AI Nodes",
        content: "AI computing infrastructure is susceptible to unique attack structures, including prompt injection and side-channel timing analysis.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-10T00:00:00Z" },
        tags: ["Attacks", "Prompt-Injection", "Security"],
        confidence: 0.89,
        requires_review: false,
      },
      {
        id: "c_p2",
        doc_id: "doc_cyber_compliance",
        type: "Paragraph",
        content: "When quantum decryption algorithms mature, typical RSA or symmetric systems are compromised. Pre-emptive migration to Lattice-based or Post-Quantum Cryptography (PQC) is advised.",
        temporal: { extracted_at: "2026-06-17T00:00:00Z", valid_from: "2026-06-10T00:00:00Z" },
        tags: ["Quantum", "Security", "PQC", "Lattice-Crypt"],
        confidence: 0.91,
        requires_review: false,
      },
    ];

    // Seed Nodes
    qNodes.forEach((node) => {
      // Simulate fake mock embeddings for retrieval
      node.vector_embedding = this.generateMockVectorForTags(node.tags);
      this.state.nodes[node.id] = node;
    });

    cNodes.forEach((node) => {
      node.vector_embedding = this.generateMockVectorForTags(node.tags);
      this.state.nodes[node.id] = node;
    });

    // --- Edges setup (Strict Outbound Directionality) ---
    const edges: OKFEdge[] = [
      // Quantum hierarchy (HAS_CHILD)
      { id: "e1", from: "q_ch1", to: "q_sec1_1", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },
      { id: "e2", from: "q_ch1", to: "q_sec1_2", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },
      { id: "e3", from: "q_sec1_1", to: "q_p1", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },
      { id: "e4", from: "q_sec1_1", to: "q_p2", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },
      { id: "e5", from: "q_sec1_2", to: "q_p3", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },

      // Sibling chains (NEXT_SIBLING)
      { id: "e6", from: "q_sec1_1", to: "q_sec1_2", relation: "NEXT_SIBLING", confidence: 0.95, requires_review: false },
      { id: "e7", from: "q_p1", to: "q_p2", relation: "NEXT_SIBLING", confidence: 0.95, requires_review: false },

      // Cyber hierarchy (HAS_CHILD)
      { id: "e8", from: "c_ch1", to: "c_sec1_1", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },
      { id: "e9", from: "c_ch1", to: "c_sec1_2", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },
      { id: "e10", from: "c_sec1_1", to: "c_p1", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },
      { id: "e11", from: "c_sec1_2", to: "c_p2", relation: "HAS_CHILD", confidence: 0.99, requires_review: false },

      // Cyber Sibling chains
      { id: "e12", from: "c_sec1_1", to: "c_sec1_2", relation: "NEXT_SIBLING", confidence: 0.95, requires_review: false },

      // --- Cross-Document Semantic Citations (REFERENCES / INDEXED_UNDER) ---
      // The cyber compliance document references Post-Quantum security, creating a connection back to the Quantum Superposition paper!
      { id: "e_cross1", from: "c_p2", to: "q_ch1", relation: "REFERENCES", confidence: 0.85, requires_review: false },
      { id: "e_cross2", from: "c_p2", to: "q_sec1_2", relation: "REFERENCES", confidence: 0.82, requires_review: false },
    ];

    edges.forEach((edge) => {
      this.state.edges[edge.id] = edge;
    });

    // Run clustering baseline
    this.runLouvainClusteringInternal();
  }

  /**
   * Helper to generate a standardized base64 vector based on tags
   */
  public generateMockVectorForTags(tags: string[]): number[] {
    const vectorLength = 128; // Smaller dimension for mockup
    const vec = new Array(vectorLength).fill(0).map(() => Math.random() * 0.1);
    // Standardize positions based on tag character hash
    tags.forEach((tag) => {
      let sum = 0;
      for (let i = 0; i < tag.length; i++) {
        sum += tag.charCodeAt(i);
      }
      const index = sum % vectorLength;
      vec[index] += 0.8;
    });
    // L2 Normalize
    const length = Math.sqrt(vec.reduce((sum, val) => sum + val * val, 0));
    return vec.map((val) => val / (length || 1));
  }

  // --- API Methods ---

  public getDocuments(): OKFDocument[] {
    return Object.values(this.state.documents);
  }

  public getDocumentById(docId: string): OKFDocument | undefined {
    return this.state.documents[docId];
  }

  public getNodes(): OKFNode[] {
    return Object.values(this.state.nodes);
  }

  public getNodeById(id: string): OKFNode | undefined {
    return this.state.nodes[id];
  }

  public getEdges(): OKFEdge[] {
    return Object.values(this.state.edges);
  }

  public deleteDocument(docId: string) {
    if (!this.state.documents[docId]) return;

    // Delete document
    delete this.state.documents[docId];

    // Find and delete matching nodes
    const nodeIdsToDelete = Object.values(this.state.nodes)
      .filter((n) => n.doc_id === docId)
      .map((n) => n.id);

    nodeIdsToDelete.forEach((nodeId) => {
      delete this.state.nodes[nodeId];
    });

    // Delete edges referencing these deleted nodes
    const edgeIdsToDelete = Object.values(this.state.edges)
      .filter((e) => nodeIdsToDelete.includes(e.from) || nodeIdsToDelete.includes(e.to))
      .map((e) => e.id);

    edgeIdsToDelete.forEach((edgeId) => {
      delete this.state.edges[edgeId];
    });

    this.saveToDisk();
  }

  /**
   * ACID-like Transactional Store
   */
  public atomicStore(
    document: OKFDocument,
    nodes: OKFNode[],
    edges: OKFEdge[]
  ): { success: boolean; error?: string } {
    const backupState = JSON.stringify(this.state);

    try {
      // 1. Save document index
      this.state.documents[document.doc_id] = document;

      // 2. Save Nodes, check content hashes for duplicates
      nodes.forEach((node) => {
        if (!node.id || !node.doc_id) {
          throw new Error(`Node format violation: Node ${JSON.stringify(node)} is missing id or doc_id.`);
        }
        this.state.nodes[node.id] = node;
      });

      // 3. Save Edges, enforce outbound directionality and target connectivity
      edges.forEach((edge) => {
        if (!edge.id || !edge.from || !edge.to || !edge.relation) {
          throw new Error(`Edge format violation: Edge ${JSON.stringify(edge)} missing fields.`);
        }
        // Enforce Referential Integrity
        if (!this.state.nodes[edge.from] && edge.from !== document.doc_id) {
          throw new Error(`Orphaned edge detected: Left-node '${edge.from}' does not exist.`);
        }
        if (!this.state.nodes[edge.to] && edge.to !== document.doc_id) {
          throw new Error(`Orphaned edge detected: Right-node '${edge.to}' does not exist.`);
        }
        this.state.edges[edge.id] = edge;
      });

      // Run Refinery (Louvain algorithm update)
      this.runLouvainClusteringInternal();

      // Commit Transaction
      this.saveToDisk();
      return { success: true };
    } catch (err: any) {
      console.error("[ROLLBACK] Transaction rolled back due to error:", err.message);
      // Restore on failure
      this.state = JSON.parse(backupState);
      return { success: false, error: err.message || String(err) };
    }
  }

  /**
   * Audit Review Updater
   */
  public auditNode(nodeId: string, updatedContent: string, approved: boolean): boolean {
    const node = this.state.nodes[nodeId];
    if (!node) return false;

    node.content = updatedContent;
    if (approved) {
      node.requires_review = false;
      node.confidence = 1.0;
    }
    this.saveToDisk();
    return true;
  }

  public auditEdge(edgeId: string, approved: boolean, relation?: EdgeType): boolean {
    const edge = this.state.edges[edgeId];
    if (!edge) return false;

    if (relation) {
      edge.relation = relation;
    }

    if (approved) {
      edge.requires_review = false;
      edge.confidence = 1.0;
    }
    this.saveToDisk();
    return true;
  }

  /**
   * The Louvain Clustering Refinery
   * Uses simple network layout: groups nodes based on shared vocabulary tags and edge connectivity.
   */
  public runLouvainClustering() {
    this.runLouvainClusteringInternal();
    this.saveToDisk();
  }

  private runLouvainClusteringInternal() {
    const nodes = Object.values(this.state.nodes);
    if (nodes.length === 0) return;

    // Build Adjacency Matrix
    const adj = new Map<string, Set<string>>();
    nodes.forEach((n) => adj.set(n.id, new Set<string>()));

    // Shared Tag Density
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const shared = nodes[i].tags.filter((t) => nodes[j].tags.includes(t));
        if (shared.length >= 2) {
          adj.get(nodes[i].id)!.add(nodes[j].id);
          adj.get(nodes[j].id)!.add(nodes[i].id);
        }
      }
    }

    // Direct Graph Links
    Object.values(this.state.edges).forEach((edge) => {
      if (adj.has(edge.from) && adj.has(edge.to)) {
        adj.get(edge.from)!.add(edge.to);
        adj.get(edge.to)!.add(edge.from);
      }
    });

    // Greedy modularity clustering (simplified Louvain)
    const communities = new Map<string, string>(); // Node ID -> Cluster ID
    let currentId = 0;

    // First assign each node its own cluster
    nodes.forEach((n) => {
      communities.set(n.id, `cluster_${currentId++}`);
    });

    // In iterative passes, merge neighbors if modularity increases (simulated here)
    const passes = 3;
    for (let p = 0; p < passes; p++) {
      let changed = false;
      for (const node of nodes) {
        const neighbors = adj.get(node.id) || new Set();
        if (neighbors.size === 0) continue;

        // Group neighbors by cluster and see which cluster has most representation
        const clusterCounts = new Map<string, number>();
        neighbors.forEach((neigh) => {
          const cId = communities.get(neigh);
          if (cId) {
            clusterCounts.set(cId, (clusterCounts.get(cId) || 0) + 1);
          }
        });

        // Find best neighbor cluster
        let bestCluster = communities.get(node.id)!;
        let maxCount = 0;
        clusterCounts.forEach((count, cId) => {
          if (count > maxCount) {
            maxCount = count;
            bestCluster = cId;
          }
        });

        if (bestCluster !== communities.get(node.id)) {
          communities.set(node.id, bestCluster);
          changed = true;
        }
      }
      if (!changed) break;
    }

    // Apply community clusters
    nodes.forEach((node) => {
      node.cluster_id = communities.get(node.id) || "cluster_0";
    });
  }

  /**
   * Helper text score (simplified BM25) for shallow query text-search view matching
   */
  public computeTextScore(nodeContent: string, keywords: string[]): number {
    if (keywords.length === 0) return 0;
    let occurrences = 0;
    const lowerContent = nodeContent.toLowerCase();
    keywords.forEach((kw) => {
      const regex = new RegExp(`\\b${kw.toLowerCase()}\\b`, "g");
      const matches = lowerContent.match(regex);
      if (matches) occurrences += matches.length;
    });

    // Standard saturated score curve mimicking term frequency saturation
    const score = (occurrences * 1.5) / (occurrences + 0.5);
    return score;
  }

  /**
   * Compiles and executes a simulated AQL query, logging the query in a readable, beautiful console format.
   * This handles standard crawls e.g.:
   * FOR n IN okf_nodes FILTER ...
   */
  public queryAQL(queryStr: string, bindVars: Record<string, any> = {}): {
    compiled: string;
    results: any[];
  } {
    console.log(`[AQL COMPILER] compiling query:\n${queryStr}`);
    console.log(`[AQL BINDVARS] vars:`, bindVars);

    // Standard simple parser for simulator
    let results: any[] = [];
    const normalized = queryStr.replace(/\s+/g, " ");

    if (normalized.includes("okf_search_view") || normalized.includes("COSINE_SIMILARITY")) {
      // Simulated shallow search logic
      const nodes = this.getNodes();
      results = nodes.map((n) => {
        let keywordScore = 0;
        if (bindVars.keywords) {
          keywordScore = this.computeTextScore(n.content, bindVars.keywords);
        }
        let vectorScore = 0.5; // average
        if (bindVars.vector && n.vector_embedding) {
          // calculate actual cosine similarity
          let dotProduct = 0;
          let normA = 0;
          let normB = 0;
          for (let i = 0; i < Math.min(n.vector_embedding.length, bindVars.vector.length); i++) {
            dotProduct += n.vector_embedding[i] * bindVars.vector[i];
            normA += n.vector_embedding[i] * n.vector_embedding[i];
            normB += bindVars.vector[i] * bindVars.vector[i];
          }
          vectorScore = dotProduct / (Math.sqrt(normA) * Math.sqrt(normB) || 1);
        }
        return {
          node: n,
          score: (vectorScore * 0.6) + (keywordScore * 0.4),
        };
      }).sort((a, b) => b.score - a.score).filter((item) => item.score > 0.05);
    } else if (normalized.includes("NEXT_SIBLING")) {
      // Sibling sequence matching
      results = Object.values(this.state.edges).filter((e) => e.relation === "NEXT_SIBLING");
    } else {
      // General match
      results = Object.values(this.state.nodes);
    }

    return {
      compiled: queryStr,
      results,
    };
  }
}

// Single instance
let instance: GraphDBSimulator | null = null;
export function getDB(): GraphDBSimulator {
  if (!instance) {
    instance = new GraphDBSimulator();
  }
  return instance;
}
