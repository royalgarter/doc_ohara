/**
 * Doc Ohara: Space-Time Graph schema definitions (OKF & DoCO compliant)
 */

export type NodeType =
  | "Chapter"
  | "Section"
  | "Subsection"
  | "Paragraph"
  | "Table"
  | "ListItem"
  | "Figure"
  | "Concept"
  | "Tag";

export type EdgeType =
  | "HAS_CHILD"
  | "NEXT_SIBLING"
  | "HAS_TAG"
  | "INDEXED_UNDER"
  | "REFERENCES"
  | "SUCCEEDS";

export interface SpatialMetadata {
  layout_box?: {
    x0?: number;
    y0?: number;
    x1?: number;
    y1?: number;
    page?: number;
  };
  geo_json?: {
    type: string;
    coordinates: number[];
  };
}

export interface TemporalMetadata {
  extracted_at: string; // ISO DateTime
  valid_from: string; // ISO DateTime
}

export interface OKFDocument {
  doc_id: string;
  title: string;
  content_hash: string;
  metadata?: Record<string, any>;
  created_at: string;
}

export interface OKFNode {
  id: string; // unique ID
  doc_id: string;
  type: NodeType;
  title?: string;
  content: string;
  spatial?: SpatialMetadata;
  temporal: TemporalMetadata;
  tags: string[];
  vector_embedding?: number[];
  cluster_id?: string;
  confidence: number; // 0 to 1
  requires_review: boolean;
}

export interface OKFEdge {
  id: string; // unique ID
  from: string; // node id
  to: string; // node id
  relation: EdgeType;
  confidence: number; // 0 to 1
  requires_review: boolean;
  metadata?: Record<string, any>;
}

export interface DBState {
  documents: Record<string, OKFDocument>;
  nodes: Record<string, OKFNode>;
  edges: Record<string, OKFEdge>;
}

export interface ProcessedQuery {
  raw_query: string;
  keywords: string[];
  tags: string[];
  vector: number[];
}

export interface ShallowResult {
  node: OKFNode;
  score: number; // Combined BM25 + Vector
  scores: {
    keyword: number;
    vector: number;
  };
}

export interface DeepResult {
  root_node: OKFNode;
  traversal_path: {
    direction: "UP" | "DOWN" | "SIBLING" | "SEMANTIC";
    relation: EdgeType;
    node: OKFNode;
  }[];
}
