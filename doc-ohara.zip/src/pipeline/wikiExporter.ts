/**
 * Doc Ohara: Quartz-Compatible Digital Garden Markdown Wiki Exporter
 */

import * as fs from "fs";
import * as path from "path";
import { getDB } from "../db/simulator.js";
import { OKFNode, OKFDocument, OKFEdge } from "../types.js";

export class WikiExporter {
  private db = getDB();
  private wikiDir = path.resolve("./wiki");

  /**
   * Generates and writes down the full Markdown wiki
   */
  public export(): { success: boolean; filesCreated: string[]; outputDir: string } {
    try {
      const documents = this.db.getDocuments();
      const nodes = this.db.getNodes();
      const edges = this.db.getEdges();

      const docsDir = path.join(this.wikiDir, "documents");
      if (!fs.existsSync(docsDir)) {
        fs.mkdirSync(docsDir, { recursive: true });
      }

      const filesCreated: string[] = [];

      // 1. Generate individual wiki files for each document
      documents.forEach((doc) => {
        const docNodes = nodes.filter((n) => n.doc_id === doc.doc_id);
        const relativeFilePath = `documents/${doc.doc_id}.md`;
        const absolutePath = path.join(this.wikiDir, relativeFilePath);

        let markdown = `---
title: "${doc.title}"
doc_id: "${doc.doc_id}"
extracted_at: "${doc.metadata?.extracted_at || new Date().toISOString()}"
content_hash: "${doc.content_hash}"
---

# 🌌 ${doc.title}

Welcome to the structured digital knowledge map representing **${doc.title}**. This record is processed using the Open Knowledge Format (OKF) & Document Components Ontology (DoCO).

## 📊 Document Stats
- **Total Vertices**: ${docNodes.length}
- **Ingestion Parser**: \`${doc.metadata?.parser || "Default"}\`
- **Metadata License**: \`${doc.metadata?.license || "CC-BY-4.0"}\`

---

## 🗺️ Space-Time Hierarchy

`;

        // Organize nodes by chapters/sections
        const chapters = docNodes.filter((n) => n.type === "Chapter");
        const sections = docNodes.filter((n) => n.type === "Section");
        const paragraphs = docNodes.filter((n) => n.type === "Paragraph");

        chapters.forEach((ch) => {
          markdown += `### 🏷️ ${ch.title || "Chapter"}\n\n> ${ch.content}\n\n`;

          // Find Children sections
          const childSectionEdges = edges.filter((e) => e.from === ch.id && e.relation === "HAS_CHILD");
          childSectionEdges.forEach((cse) => {
            const sec = docNodes.find((n) => n.id === cse.to && n.type === "Section");
            if (sec) {
              markdown += `#### 📁 ${sec.title || "Section"}\n\n* ${sec.content}\n\n`;

              // Find downstream paragraphs
              const childParaEdges = edges.filter((e) => e.from === sec.id && e.relation === "HAS_CHILD");
              childParaEdges.forEach((cpe) => {
                const para = docNodes.find((n) => n.id === cpe.to);
                if (para) {
                  markdown += `##### 📄 ${para.title || "Paragraph"}\n\n${para.content}\n\n`;
                  
                  // Metadata card
                  markdown += `* **Tags**: ${para.tags.map((t) => `\`#${t}\``).join(", ")}\n`;
                  markdown += `* **Confidence**: \`${para.confidence * 100}%\` ${para.requires_review ? "⚠️ *[Pending Audit Review]*" : ""}\n`;
                  if (para.cluster_id) {
                    markdown += `* ** Louvain Cluster**: \`${para.cluster_id}\`\n`;
                  }
                  markdown += `\n`;
                }
              });
            }
          });

          // Also check for direct paras under chapter if any
          const directParaEdges = edges.filter((e) => e.from === ch.id && e.relation === "HAS_CHILD");
          directParaEdges.forEach((dpe) => {
            const para = docNodes.find((n) => n.id === dpe.to && n.type === "Paragraph");
            if (para) {
              markdown += `##### 📄 ${para.title || "Paragraph"}\n\n${para.content}\n\n`;
              markdown += `* **Tags**: ${para.tags.map((t) => `\`#${t}\``).join(", ")}\n\n`;
            }
          });
        });

        // Add cross references mapping to this document
        const crossRefs = edges.filter(
          (e) => (docNodes.some((dn) => dn.id === e.from) || docNodes.some((dn) => dn.id === e.to)) && e.relation === "REFERENCES"
        );

        if (crossRefs.length > 0) {
          markdown += `---

## 🔗 Thematic Cross-References (Wikilinks)
We have mapped the following cognitive pathways connecting sections of this document with external material:

`;
          crossRefs.forEach((edge) => {
            const fromNode = nodes.find((n) => n.id === edge.from);
            const toNode = nodes.find((n) => n.id === edge.to);
            if (fromNode && toNode) {
              const isFromExternal = fromNode.doc_id !== doc.doc_id;
              const isToExternal = toNode.doc_id !== doc.doc_id;

              if (isFromExternal) {
                markdown += `- Connected inbound from external topic [[${fromNode.doc_id}]] (\`"${fromNode.title || "Concept"}"\`): *${fromNode.content.substring(0, 100)}...*\n`;
              } else if (isToExternal) {
                markdown += `- Outbound bridge referencing [[${toNode.doc_id}]] (\`"${toNode.title || "Anchor"}"\`): *${toNode.content.substring(0, 100)}...*\n`;
              }
            }
          });
          markdown += `\n`;
        }

        fs.writeFileSync(absolutePath, markdown, "utf-8");
        filesCreated.push(relativeFilePath);
      });

      // 2. Generate central wiki index.md
      const indexFilePath = path.join(this.wikiDir, "index.md");
      let indexMarkdown = `---
title: "Doc Ohara Open Knowledge Graph Garden 🌌"
---

# 📡 Welcome to Doc Ohara Open Knowledge Garden

This Digital Garden is compiled directly from **Doc Ohara's** Multi-Model Space-Time Graph Simulator. It provides the "Layer Cake" structural and thematic mappings of all ingested material.

---

## 📚 Document Catalogue
Click on a document index card below to browse its hierarchical space-time ontology.

${documents
  .map(
    (doc) =>
      `### 🗃️ [[documents/${doc.doc_id}|${doc.title}]]
- **Document ID**: \`${doc.doc_id}\`
- **Total Vertices**: ${nodes.filter((n) => n.doc_id === doc.doc_id).length} nodes
- **Smart Hash**: \`${doc.content_hash.substring(0, 16)}...\`
- **Extracted Date**: ${doc.metadata?.extracted_at || doc.created_at}
`
  )
  .join("\n")}

---

## 🧪 Global Louvain Thematic Hubs
Doc Ohara's Refinery continuously groups overlapping nodes into thematic virtual clubs. Below are the current active clusters:

`;

      // Group by cluster
      const clusters: Record<string, OKFNode[]> = {};
      nodes.forEach((node) => {
        if (node.cluster_id) {
          if (!clusters[node.cluster_id]) clusters[node.cluster_id] = [];
          clusters[node.cluster_id].push(node);
        }
      });

      Object.entries(clusters).forEach(([cId, cNodes]) => {
        indexMarkdown += `### 🌀 Hub: \`${cId}\` (Modularity Group)\n`;
        indexMarkdown += `*Consists of ${cNodes.length} related conceptual anchors:*\n\n`;
        cNodes.forEach((cn) => {
          const doc = documents.find((d) => d.doc_id === cn.doc_id);
          indexMarkdown += `- In [[documents/${cn.doc_id}|${doc?.title || "Doc"}]]: \`"${cn.title || cn.type}"\` - *${cn.content.substring(0, 80)}...*\n`;
        });
        indexMarkdown += `\n`;
      });

      indexMarkdown += `
---
*Doc Ohara Engine: Interactive Knowledge Mapper — UTC June 2026*
`;

      fs.writeFileSync(indexFilePath, indexMarkdown, "utf-8");
      filesCreated.push("index.md");

      return {
        success: true,
        filesCreated,
        outputDir: this.wikiDir,
      };
    } catch (err) {
      console.error("Failed to export wiki:", err);
      return {
        success: false,
        filesCreated: [],
        outputDir: this.wikiDir,
      };
    }
  }
}
