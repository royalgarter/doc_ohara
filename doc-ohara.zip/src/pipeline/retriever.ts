/**
 * Doc Ohara: Two-Step Hybrid Retrieval Engine (Phase 0, Phase 1, Phase 2)
 */

import { GoogleGenAI } from "@google/genai";
import { getDB } from "../db/simulator.js";
import { OKFNode, OKFEdge, ProcessedQuery, ShallowResult, DeepResult, EdgeType } from "../types.js";

// Initialize Gemini client on the server
const getGeminiClient = (): GoogleGenAI | null => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

export class SpaceTimeRetriever {
  private db = getDB();

  /**
   * Phase 0: Input Preprocessing & Semantic Tag Expansion
   */
  public async preprocessQuery(rawInput: string): Promise<ProcessedQuery> {
    // 1. Extract raw words as keywords (clean stopwords)
    const stopwords = new Set([
      "the", "a", "an", "and", "or", "but", "if", "then", "else", "when", 
      "at", "by", "from", "for", "with", "in", "on", "to", "of", "is", "was", "are", "show", "me", "how", "what", "connects"
    ]);
    const words = rawInput
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, "")
      .split(/\s+/)
      .filter((w) => w.length > 2 && !stopwords.has(w));

    // 2. Expand queries into standard semantic tags inside the knowledge graph
    const tagTaxonomy: Record<string, string[]> = {
      quantum: ["Quantum", "Physics", "Superposition", "Qubits"],
      superposition: ["Superposition", "Quantum", "Linear-Algebra"],
      qubit: ["Qubits", "Hardware", "Josephson-Junctions"],
      security: ["Security", "Compliance", "Encryption", "PQC"],
      compliance: ["Compliance", "Governance", "Sovereign-Cloud"],
      encryption: ["Encryption", "Sovereign-Cloud", "Symmetric-Crypt"],
      hack: ["Attacks", "Prompt-Injection", "Security"],
      lab: ["Lab", "Experiment", "Coherence"],
    };

    const expandedTags: string[] = [];
    words.forEach((word) => {
      if (tagTaxonomy[word]) {
        expandedTags.push(...tagTaxonomy[word]);
      }
    });

    const finalTags = Array.from(new Set(expandedTags));

    // 3. Vector generation
    let vector: number[] = [];
    const gemini = getGeminiClient();

    if (gemini) {
      try {
        const response = await gemini.models.embedContent({
          model: "gemini-embedding-2-preview",
          contents: rawInput,
        });
        if (response.embedding && response.embedding.values) {
          vector = response.embedding.values;
        }
      } catch (err) {
        // Fallback below
      }
    }

    if (vector.length === 0) {
      vector = this.db.generateMockVectorForTags(finalTags.length > 0 ? finalTags : words);
    }

    return {
      raw_query: rawInput,
      keywords: words,
      tags: finalTags,
      vector,
    };
  }

  /**
   * Phase 1: Shallow Context Breadth Search (BM25 term matching + Cosine Similarity)
   */
  public async getShallowContext(
    processed: ProcessedQuery,
    limit = 5
  ): Promise<ShallowResult[]> {
    const nodes = this.db.getNodes();
    const results: ShallowResult[] = [];

    nodes.forEach((node) => {
      // BM25 term weighting
      const keywordScore = this.db.computeTextScore(node.content, processed.keywords);

      // Vector Cosine Similarity
      let vectorScore = 0.5; // Neutral default
      if (node.vector_embedding && processed.vector) {
        let dot = 0;
        let normA = 0;
        let normB = 0;
        const len = Math.min(node.vector_embedding.length, processed.vector.length);

        for (let i = 0; i < len; i++) {
          dot += node.vector_embedding[i] * processed.vector[i];
          normA += node.vector_embedding[i] * node.vector_embedding[i];
          normB += processed.vector[i] * processed.vector[i];
        }
        vectorScore = dot / (Math.sqrt(normA) * Math.sqrt(normB) || 1);
      }

      // Exact Tag Match boost
      const tagMatchCount = node.tags.filter((t) => processed.tags.includes(t)).length;
      const tagBoost = tagMatchCount > 0 ? 0.15 * Math.min(tagMatchCount, 3) : 0;

      // Composite scoring formula: (Vector similarity * 0.6) + (Term score * 0.4) + Tag match boost
      let composite = (vectorScore * 0.6) + (keywordScore * 0.4) + tagBoost;

      // Clamp composite score between 0 and 1
      composite = Math.max(0, Math.min(1, composite));

      results.push({
        node,
        score: parseFloat(composite.toFixed(4)),
        scores: {
          keyword: parseFloat(keywordScore.toFixed(4)),
          vector: parseFloat(vectorScore.toFixed(4)),
        },
      });
    });

    // Sort descending by score
    return results.sort((a, b) => b.score - a.score).slice(0, limit);
  }

  /**
   * Phase 2: Deep Context Depth Traversal (Walking graph from anchor selected node)
   */
  public getDeepContext(anchorId: string, depth = 2): DeepResult | null {
    const rootNode = this.db.getNodeById(anchorId);
    if (!rootNode) return null;

    const edges = this.db.getEdges();
    const traversalPath: DeepResult["traversal_path"] = [];
    const visitedNodes = new Set<string>([anchorId]);

    // Graph Walk Step 1: Upward structural headings (Find parent Chapter / Section nodes)
    // Chapters and Sections link downstream toward Section and Paragraph respectively.
    // Parent node is the 'from' in `HAS_CHILD` edges where 'to' is our node.
    const parentEdges = edges.filter((e) => e.to === anchorId && e.relation === "HAS_CHILD");
    parentEdges.forEach((edge) => {
      const parentNode = this.db.getNodeById(edge.from);
      if (parentNode && !visitedNodes.has(parentNode.id)) {
        visitedNodes.add(parentNode.id);
        traversalPath.push({
          direction: "UP",
          relation: "HAS_CHILD",
          node: parentNode,
        });
      }
    });

    // Graph Walk Step 2: Sequential siblings (NEXT_SIBLING flow in both directions)
    // Left sibling (edge pointing to anchorId)
    const prevSiblingEdges = edges.filter((e) => e.to === anchorId && e.relation === "NEXT_SIBLING");
    prevSiblingEdges.forEach((edge) => {
      const prevNode = this.db.getNodeById(edge.from);
      if (prevNode && !visitedNodes.has(prevNode.id)) {
        visitedNodes.add(prevNode.id);
        traversalPath.push({
          direction: "SIBLING",
          relation: "NEXT_SIBLING",
          node: prevNode,
        });
      }
    });

    // Right sibling (edges pointing from anchorId outwards)
    const nextSiblingEdges = edges.filter((e) => e.from === anchorId && e.relation === "NEXT_SIBLING");
    nextSiblingEdges.forEach((edge) => {
      const nextNode = this.db.getNodeById(edge.to);
      if (nextNode && !visitedNodes.has(nextNode.id)) {
        visitedNodes.add(nextNode.id);
        traversalPath.push({
          direction: "SIBLING",
          relation: "NEXT_SIBLING",
          node: nextNode,
        });
      }
    });

    // Graph Walk Step 3: Semantic jump references / shared Louvain clusters
    // Discover cross-document surprising links or explicit tag clusters!
    const semanticEdges = edges.filter(
      (e) => (e.from === anchorId || e.to === anchorId) && ["REFERENCES", "INDEXED_UNDER", "HAS_TAG"].includes(e.relation)
    );

    semanticEdges.forEach((edge) => {
      const targetId = edge.from === anchorId ? edge.to : edge.from;
      const targetNode = this.db.getNodeById(targetId);
      if (targetNode && !visitedNodes.has(targetNode.id)) {
        visitedNodes.add(targetNode.id);
        traversalPath.push({
          direction: "SEMANTIC",
          relation: edge.relation,
          node: targetNode,
        });
      }
    });

    // If anchor node belongs to a Louvain cluster, find up to 2 other nodes with the exact same cluster ID!
    if (rootNode.cluster_id) {
      const fellows = this.db.getNodes().filter((n) => n.cluster_id === rootNode.cluster_id && n.id !== rootNode.id);
      fellows.slice(0, 2).forEach((fn) => {
        if (!visitedNodes.has(fn.id)) {
          visitedNodes.add(fn.id);
          traversalPath.push({
            direction: "SEMANTIC",
            relation: "INDEXED_UNDER", // Semantic grouping proxy tag
            node: fn,
          });
        }
      });
    }

    return {
      root_node: rootNode,
      traversal_path: traversalPath,
    };
  }

  /**
   * Multi-Hop retrieval integration block, compiling deep context into a beautiful prompt string 
   * ready for LLM consumption.
   */
  public generateFullContextBlock(deep: DeepResult): string {
    const parentHeader = deep.traversal_path
      .filter((p) => p.direction === "UP")
      .map((p) => `[STRUCTURAL HEAD: ${p.node.title || p.node.type}] ${p.node.content}`)
      .join("\n");

    const flowSiblings = deep.traversal_path
      .filter((p) => p.direction === "SIBLING")
      .map((p) => `[FLOW CONTEXT / SIBLING: ${p.node.title || "Para"}] ${p.node.content}`)
      .join("\n");

    const semanticWeb = deep.traversal_path
      .filter((p) => p.direction === "SEMANTIC")
      .map((p) => `[THEMATIC LINK / ${p.node.type} (${p.relation})]: ${p.node.content}`)
      .join("\n");

    return `
=============================================
SPACE-TIME CONTEXT: "${deep.root_node.title || "Target Segment"}"
=============================================
PRIMARY NODE CONTENT: 
${deep.root_node.content}

${parentHeader ? `STRUCTURAL HEADINGS:\n${parentHeader}\n\n` : ""}
${flowSiblings ? `SEQUENCE & FLOW:\n${flowSiblings}\n\n` : ""}
${semanticWeb ? `CROSS-REFS & THEMATIC CLUSTERS:\n${semanticWeb}\n\n` : ""}
=============================================
`.trim();
  }
}
